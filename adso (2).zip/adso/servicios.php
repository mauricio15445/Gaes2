<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/servicios.css">
    <link rel="stylesheet" href="assets/css/templatemo.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/custom.css">
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">

    <style>
        /* Estilo para el texto de los servicios en negro */
        .servicio-item h3 a {
            color: black;
            text-decoration: none; /* Elimina el subrayado del enlace */
        }
    </style>
    <title>Frenos y Suspensiones CH - Servicios</title>
</head>
<body>

<!-- Header -->
<nav class="navbar navbar-expand-lg navbar-light shadow custom-header">
    <div class="container d-flex justify-content-between align-items-center">

        <a class="navbar-brand text-success logo h1 align-self-center" href="index.php">
            Frenos y Suspensiones
        </a>

        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#templatemo_main_nav" aria-controls="templatemo_main_nav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse flex-fill d-lg-flex justify-content-lg-between" id="templatemo_main_nav">
            <div class="flex-fill">
                <ul class="nav navbar-nav d-flex flex-row mx-lg-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="cliente.php">Inicio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="sobre.php">Acerca De</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="inventa.php">Productos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="l.php">Contactenos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="agendaclien.php">Agendar Cita</a>
                    </li>
                


                </ul>
            </div>
            <a class="nav-icon position-relative text-decoration-none" href="#">
                <i class="fa fa-fw fa-user text-dark mr-3"></i>
            </a>
            
        </div>
    </div>
</nav>
<!-- Close Header -->


    <main>
        <section id="servicios">
        <br>
            <center><h1>Nuestros Servicios</h1></center>
            <br><br>
            <ul class="servicios-lista">
                <li class="servicio-item">
                    <h3><a href="pago.php?servicio=Reparación%20de%20Motores">Reparación de Motores</a></h3>
                    <p>Reparamos y mantenemos motores de automóviles.</p>
                </li>
                <li class="servicio-item">
                    <h3><a href="pago.php?servicio=Cambio%20de%20Aceite%20y%20Filtros">Cambio de Aceite y Filtros</a></h3>
                    <p>Realizamos cambios de aceite y filtros.</p>
                </li>
                <li class="servicio-item">
                    <h3><a href="pago.php?servicio=Revisión%20y%20Reparación%20de%20Frenos">Revisión y Reparación de Frenos</a></h3>
                    <p>Inspeccionamos y reparamos sistemas de frenos.</p>
                </li>
                <li class="servicio-item">
                    <h3><a href="pago.php?servicio=Alineación%20y%20Balanceo">Alineación y Balanceo</a></h3>
                    <p>Alineamos y balanceamos las ruedas de tu vehículo.</p>
                </li>
                <li class="servicio-item">
                    <h3><a href="pago.php?servicio=Diagnóstico%20de%20Problemas">Diagnóstico de Problemas</a></h3>
                    <p>Utilizamos herramientas avanzadas para diagnosticar problemas.</p>
                </li>
            </ul>
        </section>
    </main>

  
    <!-- Start Footer -->
    <footer class="bg-dark" id="tempaltemo_footer">
        <div class="container">
            <div class="row">

                <div class="col-md-4 pt-5">
                    <h2 class="h2 text-success border-bottom pb-3 border-light logo">Frenos y Suspensiones</h2>
                    <ul class="list-unstyled text-light footer-link-list">
                        <li>
                            <i class="fas fa-map-marker-alt fa-fw"></i>
                            Cra 87 # 51B–78S', Bosa, Bogotá
                        </li>
                        <li>
                            <i class="fa fa-phone fa-fw"></i>
                            <a class="text-decoration-none" href="tel:3104298615">3104298615</a>
                        </li>
                        <li>
                            <i class="fa fa-envelope fa-fw"></i>
                            <a class="text-decoration-none" href="mailto:frenosysupenciones0@gmail.com">frenosysupenciones0@gmail.com</a>
                        </li>
                    </ul>
                </div>

                <div class="col-md-4 pt-5">
                    <h2 class="h2 text-light border-bottom pb-3 border-light">Productos</h2>
                    <ul class="list-unstyled text-light footer-link-list">
                        <li><a class="text-decoration-none" href="#">Amortiguador de Logan</a></li>
                        <li><a class="text-decoration-none" href="#">Bandas de Logan</a></li>
                        <li><a class="text-decoration-none" href="#">Bandas para Spark</a></li>
                        <li><a class="text-decoration-none" href="#">Amortiguador de Spark</a></li>
                        <li><a class="text-decoration-none" href="#">Soporte de motor Kia Ion</a></li>
                        <li><a class="text-decoration-none" href="#">Soporte Motor Logan/Sandero 2016</a></li>
                        <li><a class="text-decoration-none" href="#">Soporte de Motor Spark GT / Beat</a></li>
                    </ul>
                </div>

                <div class="col-md-4 pt-5">
                    <h2 class="h2 text-light border-bottom pb-3 border-light">Informacion</h2>
                    <ul class="list-unstyled text-light footer-link-list">
                        <li><a class="text-decoration-none" href="">Inicio</a></li>
                        <li><a class="text-decoration-none" href="#">Acerca de</a></li>
                        <li><a class="text-decoration-none" href="productos.php">Productos</a></li>
                        <li><a class="text-decoration-none" href="#">Contactenos</a></li>
                        <li><a class="text-decoration-none" href="iniciarsesion.php">Agendar Cita</a></li>

                    </ul>
                </div>

            </div>

            <div class="row text-light mb-4">
                <div class="col-12 mb-3">
                    <div class="w-100 my-3 border-top border-light"></div>
                </div>
                <div class="col-auto me-auto">
                    <ul class="list-inline text-left footer-icons">
                        <li class="list-inline-item border border-light rounded-circle text-center">
                            <a class="text-light text-decoration-none" target="_blank" href="http://facebook.com/"><i class="fab fa-facebook-f fa-lg fa-fw"></i></a>
                        </li>
                        <li class="list-inline-item border border-light rounded-circle text-center">
                            <a class="text-light text-decoration-none" target="_blank" href="https://www.instagram.com/"><i class="fab fa-instagram fa-lg fa-fw"></i></a>
                        </li>
                        <li class="list-inline-item border border-light rounded-circle text-center">
                            <a class="text-light text-decoration-none" target="_blank" href="https://twitter.com/"><i class="fab fa-twitter fa-lg fa-fw"></i></a>
                        </li>
                        <li class="list-inline-item border border-light rounded-circle text-center">
                            <a class="text-light text-decoration-none" target="_blank" href="https://www.linkedin.com/"><i class="fab fa-linkedin fa-lg fa-fw"></i></a>
                        </li>
                    </ul>
                </div>
                <div class="col-auto">
                    <label class="sr-only" for="subscribeEmail">Correo Electronico</label>
                    <div class="input-group mb-2">
                        <input type="text" class="form-control bg-dark border-light" id="subscribeEmail" placeholder="Correo Electronico">
                        <div class="input-group-text btn-success text-light">Suscribete</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="w-100 bg-black py-3">
            <div class="container">
                <div class="row pt-2">
                    <div class="col-12">
                        <p class="text-left text-light">
                            Copyright &copy; Frenos y Suspensiones
                        </p>
                    </div>
                </div>
            </div>
        </div>

    </footer>
    <!-- End Footer -->

   
</body>
</html>

