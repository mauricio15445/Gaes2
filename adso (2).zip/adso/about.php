<!DOCTYPE html>
<html lang="en">

<head>
    <title>Frenos y Suspenciones</title>

    <style>
       
       body {
            background-color: #f8f9fa;
        }

       

    .vision-card,
    .mission-card {
        border-top: 2px solid #000;
        border-bottom: 2px solid #000;
        margin-bottom: 20px; /* Ajusta este valor para cambiar el margen inferior de las tarjetas */
        margin-top: 20px;
    }

    #tempaltemo_footer {
        margin-top: 40px; /* Ajusta este valor para cambiar el margen superior del pie de página */
    }

        .vision-card {
            border-left: 2px solid #000;
        }

        .mission-card {
            border-right: 2px solid #000;
        }

        .card {
            border: none;
        }

        .card-body {
            overflow: hidden;
        }
   

    
    #templatemo_main_nav {
        margin-left: 200px; /* Ajusta este valor según tus necesidades */
    }
    

      </style>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/templatemo.css">
    <link rel="stylesheet" href="assets/css/custom.css">

    <!-- Load fonts style after rendering the layout styles -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;200;300;400;500;700;900&display=swap">
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
    <!-- TemplateMo 559 Zay Shop https://templatemo.com/tm-559-zay-shop -->
</head>

<body>
    <!-- Start Top Nav -->
    <nav class="navbar navbar-expand-lg bg-dark navbar-light d-none d-lg-block" id="templatemo_nav_top">
        <div class="container text-light">
            <div class="w-100 d-flex justify-content-between">
                <div>
                    <i class="fa fa-envelope mx-2"></i>
                    <a class="navbar-sm-brand text-light text-decoration-none" href="mailto:frenosysupenciones0@gmail.com">frenosysupenciones0@gmail.com</a>
                    <i class="fa fa-phone mx-2"></i>
                    <a class="navbar-sm-brand text-light text-decoration-none" href="tel:3104298615">3104298615</a>
                </div>
                <div>
                    <a class="text-light" href="https://fb.com/templatemo" target="_blank" rel="sponsored"><i class="fab fa-facebook-f fa-sm fa-fw me-2"></i></a>
                    <a class="text-light" href="https://www.instagram.com/" target="_blank"><i class="fab fa-instagram fa-sm fa-fw me-2"></i></a>
                    <a class="text-light" href="https://twitter.com/" target="_blank"><i class="fab fa-twitter fa-sm fa-fw me-2"></i></a>
                    <a class="text-light" href="https://www.linkedin.com/" target="_blank"><i class="fab fa-linkedin fa-sm fa-fw"></i></a>
                </div>
            </div>
        </div>
    </nav>
    <!-- Close Top Nav -->
<!-- Header -->
<nav class="navbar navbar-expand-lg navbar-light shadow custom-header">
    <div class="container d-flex justify-content-between align-items-center">

        <a class="navbar-brand text-success logo h1 align-self-center" href="index.php">
            Frenos y Suspensiones
        </a>

        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#templatemo_main_nav" aria-controls="templatemo_main_nav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse flex-fill d-lg-flex justify-content-lg-between" id="templatemo_main_nav">
            <div class="flex-fill">
                <ul class="nav navbar-nav d-flex flex-row mx-lg-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Inicio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">Acerca De</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="productos.php">Productos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contactenos</a>
                    </li>
                
<!-- Registrarse -->
<li class="nav-item">
    <a class="nav-link" href="iniciarsesion.php">Registrarse</a>
    <div class="nav-link-sub">
        <a href="iniciarsesion.php">Iniciar Sesion</a>
        <!-- Agrega más opciones según sea necesario -->
    </div>
</li>

                </ul>
            </div>
            <div class="navbar align-self-center d-flex">
                <div class="d-lg-none flex-sm-fill mt-3 mb-4 col-7 col-sm-auto pr-3">
                    <div class="input-group">
                        <input type="text" class="form-control" id="inputMobileSearch" placeholder="Search ...">
                        <div class="input-group-text">
                            <i class="fa fa-fw fa-search"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</nav>
<!-- Close Header -->

    <!-- Modal -->
    <div class="modal fade bg-white" id="templatemo_search" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="w-100 pt-1 mb-5 text-right">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="" method="get" class="modal-content modal-body border-0 p-0">
                <div class="input-group mb-2">
                    <input type="text" class="form-control" id="inputModalSearch" name="q" placeholder="Search ...">
                    <button type="submit" class="input-group-text bg-success text-light">
                        <i class="fa fa-fw fa-search text-white"></i>
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Banner -->
    <section class="bg-success py-5">
        <div class="container text-center">
            <div class="row align-items-center py-5">
                <div class="col-md-8 mx-auto text-white">
                    <h1 class="display-4">Sobre Nosotros</h1>
                    <p class="lead">
                        Somos un equipo de expertos en mecánica, listos para atender todas tus necesidades automotrices de forma virtual. Desde diagnósticos remotos hasta reparaciones, estamos aquí para hacer que el mantenimiento de tu vehículo sea fácil y conveniente. Con herramientas avanzadas y transparencia total, confía en nosotros para mantener tu automóvil en excelente estado, ¡todo desde la comodidad de tu hogar!
                    </p>
                </div>
            </div>
        </div>
    </section>
  <!-- Visión y Misión -->
  <div class="container mt-5">
    <div class="row">
        <!-- Visión -->
        <div class="col-md-6">
            <div class="card h-100 vision-card">
                <div class="card-body">
                    <h5 class="card-title text-center">Visión</h5>
                    <p class="card-text">Ser el referente líder en servicios de frenos y suspensiones en línea, ofreciendo soluciones mecánicas de calidad excepcional y servicio al cliente insuperable. Nos esforzamos por ser la primera opción para los propietarios de vehículos que buscan comodidad, confianza y excelencia en el mantenimiento de frenos y suspensiones, brindando tranquilidad y seguridad en cada viaje.</p>
                </div>
            </div>
        </div>

        <!-- Misión -->
        <div class="col-md-6">
            <div class="card h-100 mission-card">
                <div class="card-body">
                    <h5 class="card-title text-center">Misión</h5>
                    <p class="card-text">En Frenos y Suspensiones en Línea, nuestra misión es proporcionar servicios de mantenimiento y reparación de frenos y suspensiones de la más alta calidad, utilizando tecnología de vanguardia y un equipo altamente capacitado. Nos comprometemos a simplificar la experiencia del cliente, ofreciendo un taller en línea fácil de usar que brinda transparencia, conveniencia y asesoramiento experto.</p>
                </div>
            </div>
        </div>
    </div>
</div>
  
      <!-- Bootstrap JS y Popper.js (necesarios para algunas funcionalidades de Bootstrap) -->
      <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- Footer -->
    <footer class="bg-dark" id="tempaltemo_footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4 pt-5">
                    <h2 class="h2 text-success border-bottom pb-3 border-light logo">Frenos y Suspensiones</h2>
                    <ul class="list-unstyled text-light footer-link-list">
                        <li>
                            <i class="fas fa-map-marker-alt fa-fw"></i>
                            Cra 87 # 51B–78S', Bosa, Bogotá
                        </li>
                        <li>
                            <i class="fa fa-phone fa-fw"></i>
                            <a class="text-decoration-none" href="tel:3104298615">3104298615</a>
                        </li>
                        <li>
                            <i class="fa fa-envelope fa-fw"></i>
                            <a class="text-decoration-none" href="mailto:frenosysupenciones0@gmail.com">frenosysupenciones0@gmail.com</a>
                        </li>
                    </ul>
                </div>

                <div class="col-md-4 pt-5">
                    <h2 class="h2 text-light border-bottom pb-3 border-light">Productos</h2>
                    <ul class="list-unstyled text-light footer-link-list">
                        <li><a class="text-decoration-none" href="#">Amortiguador de Logan</a></li>
                        <li><a class="text-decoration-none" href="#">Bandas de Logan</a></li>
                        <li><a class="text-decoration-none" href="#">Bandas para Spark</a></li>
                        <li><a class="text-decoration-none" href="#">Amortiguador de Spark</a></li>
                        <li><a class="text-decoration-none" href="#">Soporte de motor Kia Ion</a></li>
                        <li><a class="text-decoration-none" href="#">Soporte Motor Logan/Sandero 2016</a></li>
                        <li><a class="text-decoration-none" href="#">Soporte de Motor Spark GT / Beat</a></li>
                    </ul>
                </div>

                <div class="col-md-4 pt-5">
                    <h2 class="h2 text-light border-bottom pb-3 border-light">Informacion</h2>
                    <ul class="list-unstyled text-light footer-link-list">
                        <li><a class="text-decoration-none" href="index.php">Inicio</a></li>
                        <li><a class="text-decoration-none" href="about.php">Acerca de</a></li>
                        <li><a class="text-decoration-none" href="shop.php">Productos</a></li>
                        <li><a class="text-decoration-none" href="contact.php">Contactenos</a></li>
                        <li><a class="text-decoration-none" href="iniciarsesion.php">Agendar Cita</a></li>
                    </ul>
                </div>
            </div>

            <div class="row text-light mb-4">
                <div class="col-12 mb-3">
                    <div class="w-100 my-3 border-top border-light"></div>
                </div>
                <div class="col-auto me-auto">
                    <ul class="list-inline text-left footer-icons">
                        <li class="list-inline-item border border-light rounded-circle text-center">
                            <a class="text-light text-decoration-none" target="_blank" href="http://facebook.com/"><i class="fab fa-facebook-f fa-lg fa-fw"></i></a>
                        </li>
                        <li class="list-inline-item border border-light rounded-circle text-center">
                            <a class="text-light text-decoration-none" target="_blank" href="https://www.instagram.com/"><i class="fab fa-instagram fa-lg fa-fw"></i></a>
                        </li>
                        <li class="list-inline-item border border-light rounded-circle text-center">
                            <a class="text-light text-decoration-none" target="_blank" href="https://twitter.com/"><i class="fab fa-twitter fa-lg fa-fw"></i></a>
                        </li>
                        <li class="list-inline-item border border-light rounded-circle text-center">
                            <a class="text-light text-decoration-none" target="_blank" href="https://www.linkedin.com/"><i class="fab fa-linkedin fa-lg fa-fw"></i></a>
                        </li>
                    </ul>
                </div>
                <div class="col-auto">
                    <label class="sr-only" for="subscribeEmail">Correo Electronico</label>
                    <div class="input-group mb-2">
                        <input type="text" class="form-control bg-dark border-light" id="subscribeEmail" placeholder="Correo Electronico">
                        <div class="input-group-text btn-success text-light">Suscribete</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="w-100 bg-black py-3">
            <div class="container">
                <div class="row pt-2">
                    <div class="col-12">
                        <p class="text-left text-light">
                            Copyright &copy; Frenos y Suspensiones
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Close Footer -->

    <!-- Script -->
    <script src="assets/js/jquery-1.11.0.min.js"></script>
    <script src="assets/js/jquery-migrate-1.2.1.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/templatemo.js"></script>
    <script src="assets/js/custom.js"></script>
    <!-- Close Script -->
</body>

</html>
