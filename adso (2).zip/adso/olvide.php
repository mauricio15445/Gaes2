<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Olvidé mi contraseña</title>
    <style>
        body {
            background-color: #e0f7fa; /* Fondo verde claro */
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        form {
            max-width: 400px;
            width: 100%;
            padding: 20px;
            background-color: #ffffff; /* Fondo blanco */
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            position: relative;
        }

        .back-link {
            position: absolute;
            top: 10px;
            left: 10px;
            text-decoration: none;
            color: #00796b; /* Verde más oscuro */
            font-weight: bold;
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: #4caf50; /* Verde */
            color: #fff;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049; /* Verde más oscuro */
        }

        p {
            color: #00796b; /* Verde más oscuro para el mensaje de éxito */
        }
    </style>
</head>
<body>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <a href="iniciarsesion.php" class="back-link">&#9665; Atrás</a>
        <h2>Olvidé mi contraseña</h2>

        <?php
        // Si se envió el formulario, muestra un mensaje de éxito
        if (isset($message)) {
            echo '<p>' . $message . '</p>';
        } else {
            // Si no se ha enviado el formulario o ha habido un error, muestra el formulario
        ?>
        
        <label for="email">Correo electrónico:</label>
        <input type="email" name="email" required>
        <br>
        <input type="submit" value="Enviar">
        
        <?php
        }
        ?>
    </form>
</body>
</html>
