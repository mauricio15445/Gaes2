<?php

$servername = "tu_servidor_mysql";
$username = "tu_usuario_mysql";
$password = "tu_contrasena_mysql";
$dbname = "tu_nombre_de_base_de_datos";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

?>
