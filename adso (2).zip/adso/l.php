<!DOCTYPE html>
<html lang="en">

<head>
    <title>Frenos y Suspensiones</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/templatemo.css">
    <link rel="stylesheet" href="assets/css/custom.css">

    <!-- Load fonts style after rendering the layout styles -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;200;300;400;500;700;900&display=swap">
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">

    <!-- Load map styles -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A==" crossorigin="" />

</head>


<style>
    
    #templatemo_main_nav {
        margin-left: 200px; /* Ajusta este valor según tus necesidades */
    }
    .body {
background-color: white;
            margin: 0;
            padding: 0;
        }

        .nav-icon {
            position: relative;
            text-decoration: none;
            cursor: pointer;
        }

        .nav-icon i {
            font-size: 24px;
            color: #333;
        }

        .user-list-container {
            display: none;
            position: absolute;
            background-color: white;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
            z-index: 1;
            top: 30px; /* Ajusta la distancia vertical según sea necesario */
            right: 10px; /* Ajusta la distancia horizontal según sea necesario */
            padding: 10px;
            border-radius: 4px;
        }

        .nav-icon:hover + .user-list-container,
        .user-list-container:hover {
            display: block;
        }

        .user-list {
            margin: 0;
            padding: 0;
            list-style-type: none;
        }

        .user-list li {
            padding: 8px 0;
            border-bottom: 1px solid #eee; /* Línea divisoria entre elementos de la lista */
        }

        .user-list li:last-child {
            border-bottom: none; /* Elimina la línea divisoria del último elemento */
        }

        .user-list a {
            text-decoration: none;
            color: #333;
        }
    
</style>
<body>
    <!-- Start Top Nav -->
    <nav class="navbar navbar-expand-lg bg-dark navbar-light d-none d-lg-block" id="templatemo_nav_top">
        <div class="container text-light">
            <div class="w-100 d-flex justify-content-between">
                <div>
                    <i class="fa fa-envelope mx-2"></i>
                    <a class="navbar-sm-brand text-light text-decoration-none" href="mailto:frenosysupenciones0@gmail.com">frenosysupenciones0@gmail.com</a>
                    <i class="fa fa-phone mx-2"></i>
                    <a class="navbar-sm-brand text-light text-decoration-none" href="tel:3104298615">3104298615</a>
                </div>
                <div>
                    <a class="text-light" href="https://fb.com/templatemo" target="_blank" rel="sponsored"><i class="fab fa-facebook-f fa-sm fa-fw me-2"></i></a>
                    <a class="text-light" href="https://www.instagram.com/" target="_blank"><i class="fab fa-instagram fa-sm fa-fw me-2"></i></a>
                    <a class="text-light" href="https://twitter.com/" target="_blank"><i class="fab fa-twitter fa-sm fa-fw me-2"></i></a>
                    <a class="text-light" href="https://www.linkedin.com/" target="_blank"><i class="fab fa-linkedin fa-sm fa-fw"></i></a>
                </div>
            </div>
        </div>
    </nav>
    <!-- Close Top Nav -->

<!-- Header -->
<nav class="navbar navbar-expand-lg navbar-light shadow custom-header">
    <div class="container d-flex justify-content-between align-items-center">

        <a class="navbar-brand text-success logo h1 align-self-center" href="index.php">
            Frenos y Suspensiones
        </a>

        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#templatemo_main_nav" aria-controls="templatemo_main_nav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse flex-fill d-lg-flex justify-content-lg-between" id="templatemo_main_nav">
            <div class="flex-fill">
                <ul class="nav navbar-nav d-flex flex-row mx-lg-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="cliente.php">Inicio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="sobre.php">Acerca De</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="inventa.php">Productos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="l.php">Contactenos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="agendaclien.php">Agendar Cita</a>
                    </li>

                </ul>
            </div>
         
    </div>
   
<a class="nav-icon position-relative text-decoration-none" href="#" id="user-icon">
    <i class="fa fa-fw fa-user text-dark mr-3"></i>
</a>
<div class="user-list-container" id="user-list-container">
    <ul class="user-list" id="user-list">
        <!-- Agrega tus elementos de lista aquí -->
        <li><a href="#">Perfil</a></li>
        <li><a href="#">Configuración</a></li>
        <li><a href="iniciarsesion.php">Cerrar Sesión</a></li>
    </ul>
</div>

    
</nav>
<!-- Close Header -->
    <!-- Modal -->
    <div class="modal fade bg-white" id="templatemo_search" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="w-100 pt-1 mb-5 text-right">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="" method="get" class="modal-content modal-body border-0 p-0">
                <div class="input-group mb-2">
                    <input type="text" class="form-control" id="inputModalSearch" name="q" placeholder="Search ...">
                    <button type="submit" class="input-group-text bg-success text-light">
                        <i class="fa fa-fw fa-search text-white"></i>
                    </button>
                </div>
            </form>
        </div>
    </div>  
    
    <section class="container mt-5 mb-4">
        <div class="row">
            <div class="col-md-6 m-auto">
                <h3 class="text-center mb-4">Contáctenos</h3>
                <form id="contact-form" method="POST" action="formulario-contacto.php">
                    <div class="mb-3">
                        <label for="name" class="form-label font-weight-bold">Nombre</label>
                        <input type="text" class="form-control border-bottom border-dark" id="name" name="name" required>
                    </div>
    
                    <div class="mb-3">
                        <label for="apellido" class="form-label font-weight-bold">Apellido</label>
                        <input type="text" class="form-control border-bottom border-dark" id="apellido" name="apellido" required>
                    </div>
    
                    <div class="mb-3">
                        <label for="email" class="form-label font-weight-bold">Email</label>
                        <input type="email" class="form-control border-bottom border-dark" id="email" name="email" required pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$">
                        <div id="emailError" class="form-text text-danger"></div>
                    </div>
    
                    <div class="mb-3">
                        <label for="message" class="form-label font-weight-bold">Mensaje</label>
                        <textarea class="form-control border-bottom border-dark" id="message" name="message" rows="4" required></textarea>
                    </div>
    
                    <div class="text-center">
                        <button type="submit" class="btn btn-success">Enviar</button>
                        <a href="index.php" class="btn btn-success">Volver</a>
                    </div>
                </form>
            </div>
        </div>
    </section>
    <script>
        document.getElementById("contact-form").addEventListener("submit", function (event) {
            var emailInput = document.getElementById("email");
            var emailError = document.getElementById("emailError");
    
            if (!emailInput.checkValidity()) {
                event.preventDefault();
                emailError.textContent = "Ingresa un correo válido";
            } else {
                emailError.textContent = "";
            }
        });
    </script>
    
    
    <script src="https://code.jquery.com/jquery-2.1.4.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.1/js/materialize.min.js"></script>
    <script>
        function enviarFormulario() {
            // Validar todos los campos antes de enviar
            const nombre = document.getElementById("name").value;
            const apellido = document.getElementById("apellido").value;
            const email = document.getElementById("email").value;
            const mensaje = document.getElementById("message").value;
    
            if (!nombre || !apellido || !email || !mensaje) {
                alert("Por favor, complete todos los campos.");
                return;
            }
    
            // Cambiar la acción del formulario antes de enviarlo
            document.getElementById("contact-form").action = "error500";
    
            // Enviar el formulario
            document.getElementById("contact-form").submit();
        }
    </script>
    

    <!-- Start Footer -->
    <footer class="bg-dark" id="tempaltemo_footer">
        <div class="container">
            <div class="row">

                <div class="col-md-4 pt-5">
                    <h2 class="h2 text-success border-bottom pb-3 border-light logo">Frenos y Suspensiones</h2>
                    <ul class="list-unstyled text-light footer-link-list">
                        <li>
                            <i class="fas fa-map-marker-alt fa-fw"></i>
                            Cra 87 # 51B–78S', Bosa, Bogotá
                        </li>
                        <li>
                            <i class="fa fa-phone fa-fw"></i>
                            <a class="text-decoration-none" href="tel:3104298615">3104298615</a>
                        </li>
                        <li>
                            <i class="fa fa-envelope fa-fw"></i>
                            <a class="text-decoration-none" href="mailto:frenosysupenciones0@gmail.com">frenosysupenciones0@gmail.com</a>
                        </li>
                    </ul>
                </div>

                <div class="col-md-4 pt-5">
                    <h2 class="h2 text-light border-bottom pb-3 border-light">Productos</h2>
                    <ul class="list-unstyled text-light footer-link-list">
                        <li><a class="text-decoration-none" href="#">Amortiguador de Logan</a></li>
                        <li><a class="text-decoration-none" href="#">Bandas de Logan</a></li>
                        <li><a class="text-decoration-none" href="#">Bandas para Spark</a></li>
                        <li><a class="text-decoration-none" href="#">Amortiguador de Spark</a></li>
                        <li><a class="text-decoration-none" href="#">Soporte de motor Kia Ion</a></li>
                        <li><a class="text-decoration-none" href="#">Soporte Motor Logan/Sandero 2016</a></li>
                        <li><a class="text-decoration-none" href="#">Soporte de Motor Spark GT / Beat</a></li>
                    </ul>
                </div>

                <div class="col-md-4 pt-5">
                    <h2 class="h2 text-light border-bottom pb-3 border-light">Informacion</h2>
                    <ul class="list-unstyled text-light footer-link-list">
                        <li><a class="text-decoration-none" href="">Inicio</a></li>
                        <li><a class="text-decoration-none" href="#">Acerca de</a></li>
                        <li><a class="text-decoration-none" href="productos.php">Productos</a></li>
                        <li><a class="text-decoration-none" href="#">Contactenos</a></li>
                        <li><a class="text-decoration-none" href="iniciarsesion.php">Agendar Cita</a></li>

                    </ul>
                </div>

            </div>

            <div class="row text-light mb-4">
                <div class="col-12 mb-3">
                    <div class="w-100 my-3 border-top border-light"></div>
                </div>
                <div class="col-auto me-auto">
                    <ul class="list-inline text-left footer-icons">
                        <li class="list-inline-item border border-light rounded-circle text-center">
                            <a class="text-light text-decoration-none" target="_blank" href="http://facebook.com/"><i class="fab fa-facebook-f fa-lg fa-fw"></i></a>
                        </li>
                        <li class="list-inline-item border border-light rounded-circle text-center">
                            <a class="text-light text-decoration-none" target="_blank" href="https://www.instagram.com/"><i class="fab fa-instagram fa-lg fa-fw"></i></a>
                        </li>
                        <li class="list-inline-item border border-light rounded-circle text-center">
                            <a class="text-light text-decoration-none" target="_blank" href="https://twitter.com/"><i class="fab fa-twitter fa-lg fa-fw"></i></a>
                        </li>
                        <li class="list-inline-item border border-light rounded-circle text-center">
                            <a class="text-light text-decoration-none" target="_blank" href="https://www.linkedin.com/"><i class="fab fa-linkedin fa-lg fa-fw"></i></a>
                        </li>
                    </ul>
                </div>
                <div class="col-auto">
                    <label class="sr-only" for="subscribeEmail">Correo Electronico</label>
                    <div class="input-group mb-2">
                        <input type="text" class="form-control bg-dark border-light" id="subscribeEmail" placeholder="Correo Electronico">
                        <div class="input-group-text btn-success text-light">Suscribete</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="w-100 bg-black py-3">
            <div class="container">
                <div class="row pt-2">
                    <div class="col-12">
                        <p class="text-left text-light">
                            Copyright &copy; Frenos y Suspensiones
                        </p>
                    </div>
                </div>
            </div>
        </div>

    </footer>
    <!-- End Footer -->

    <script>
   document.getElementById("user-icon").addEventListener("click", function() {
    var userIcon = document.getElementById("user-icon");
    var userListContainer = document.getElementById("user-list-container");

    // Obtiene la posición del icono de usuario
    var rect = userIcon.getBoundingClientRect();

    // Establece la posición del contenedor de la lista justo debajo del icono
    userListContainer.style.left = rect.left + "px";
    userListContainer.style.top = rect.bottom + "px";

    userListContainer.classList.toggle("show");
});

// Oculta la lista si se hace clic en cualquier lugar fuera de la lista
document.addEventListener("click", function(event) {
    var userListContainer = document.getElementById("user-list-container");
    if (event.target.closest("#user-icon") === null && !userListContainer.contains(event.target)) {
        userListContainer.classList.remove("show");
    }
});

</script>

    <!-- Start Script -->
    <script src="assets/js/jquery-1.11.0.min.js"></script>
    <script src="assets/js/jquery-migrate-1.2.1.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/templatemo.js"></script>
    <script src="assets/js/custom.js"></script>
    <!-- End Script -->
</body>

</html>