
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/custom.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/templatemo.css">

   
    <title>Lista de Repuestos - Taller de Autos</title>
     <!-- Load fonts style after rendering the layout styles -->
     <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;200;300;400;500;700;900&display=swap">
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
<!-- TemplateMo 559 Zay Shop

https://templatemo.com/tm-559-zay-shop

-->
</head>

<style>
    .galeria-item a {
    text-decoration: none !important; /* Quitar subrayado */
    color: inherit !important; /* Heredar el color del texto para mantener la apariencia original */
}

        /* Cambiar el color del texto a negro */
        body, h1, h3, p, label, button {
            color: black;
        }


    
    #templatemo_main_nav {
        margin-left: 200px; /* Ajusta este valor según tus necesidades */
    }

     body {
background-color: white;
            margin: 0;
            padding: 0;
        }

        .nav-icon {
            position: relative;
            text-decoration: none;
            cursor: pointer;
        }

        .nav-icon i {
            font-size: 24px;
            color: #333;
        }

        .user-list-container {
            display: none;
            position: absolute;
            background-color: white;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
            z-index: 1;
            top: 30px; /* Ajusta la distancia vertical según sea necesario */
            right: 10px; /* Ajusta la distancia horizontal según sea necesario */
            padding: 10px;
            border-radius: 4px;
        }

        .nav-icon:hover + .user-list-container,
        .user-list-container:hover {
            display: block;
        }

        .user-list {
            margin: 0;
            padding: 0;
            list-style-type: none;
        }

        .user-list li {
            padding: 8px 0;
            border-bottom: 1px solid #eee; /* Línea divisoria entre elementos de la lista */
        }

        .user-list li:last-child {
            border-bottom: none; /* Elimina la línea divisoria del último elemento */
        }

        .user-list a {
            text-decoration: none;
            color: #333;
        }
    
    
</style>

<body>
    <!-- Start Top Nav -->
    <nav class="navbar navbar-expand-lg bg-dark navbar-light d-none d-lg-block" id="templatemo_nav_top">
        <div class="container text-light">
            <div class="w-100 d-flex justify-content-between">
                <div>
                    <i class="fa fa-envelope mx-2"></i>
                    <a class="navbar-sm-brand text-light text-decoration-none" href="mailto:frenosysupenciones0@gmail.com">frenosysupenciones0@gmail.com</a>
                    <i class="fa fa-phone mx-2"></i>
                    <a class="navbar-sm-brand text-light text-decoration-none" href="tel:3104298615">3104298615                    </a>
                </div>
                <div>
                    <a class="text-light" href="https://fb.com/templatemo" target="_blank" rel="sponsored"><i class="fab fa-facebook-f fa-sm fa-fw me-2"></i></a>
                    <a class="text-light" href="https://www.instagram.com/" target="_blank"><i class="fab fa-instagram fa-sm fa-fw me-2"></i></a>
                    <a class="text-light" href="https://twitter.com/" target="_blank"><i class="fab fa-twitter fa-sm fa-fw me-2"></i></a>
                    <a class="text-light" href="https://www.linkedin.com/" target="_blank"><i class="fab fa-linkedin fa-sm fa-fw"></i></a>
                </div>
            </div>
        </div>
    </nav>
    <!-- Close Top Nav -->

<!-- Header -->
<nav class="navbar navbar-expand-lg navbar-light shadow custom-header">
    <div class="container d-flex justify-content-between align-items-center">

        <a class="navbar-brand text-success logo h1 align-self-center" href="cliente.php">
            Frenos y Suspensiones
        </a>

        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#templatemo_main_nav" aria-controls="templatemo_main_nav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse flex-fill d-lg-flex justify-content-lg-between" id="templatemo_main_nav">
            <div class="flex-fill">
                <ul class="nav navbar-nav d-flex flex-row mx-lg-auto">
                <li class="nav-item">
                        <a class="nav-link" href="cliente.php">Inicio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="sobre.php">Acerca De</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="inventa.php">Productos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="l.php">Contactenos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="l.php">Agendar Cita</a>
                    </li>

                </ul>
            </div>
          
<a class="nav-icon position-relative text-decoration-none" href="#" id="user-icon">
    <i class="fa fa-fw fa-user text-dark mr-3"></i>
</a>
<div class="user-list-container" id="user-list-container">
    <ul class="user-list" id="user-list">
        <!-- Agrega tus elementos de lista aquí -->
        <li><a href="#">Perfil</a></li>
        <li><a href="#">Configuración</a></li>
        <li><a href="iniciarsesion.php">Cerrar Sesión</a></li>
    </ul>
</div>


  
</a>

    </div>
</nav>
<!-- Close Header -->

        <section id="galeria">
            <!-- Galería de imágenes -->
            <a class="galeria-item" style="text-decoration: none; color: black;">
    <img src="./assets/img/amorLogan.jpeg" alt="Repuesto 1" width="200" height="200">
    <h3>690.000</h3>
    <p>Amortiguador de Logan</p>
</a>
<!-- Repite esto para todas las otras etiquetas <a> dentro de .galeria-item -->

            <a  class="galeria-item" style="text-decoration: none; color: black;" >
                <img src="./assets/img/amortSpark.jpeg" alt="Repuesto 2" width="200" height="200">
                <h3>212.500</h3>
                <p>Amortiguador de Spark</p>
            </a>
            <a class="galeria-item" style="text-decoration: none; color: black;">
                <img src="./assets/img/bandasLogan.jpeg" alt="Repuesto 3" width="200" height="200">
                <h3>125.000</h3>
                <p>Bandas de Logan</p>
            </a>
            <a  class="galeria-item" style="text-decoration: none; color: black;">
                <img src="./assets/img/bandaSpark.jpeg" alt="Repuesto 4" width="200" height="200">
                <h3>70.000</h3>
                <p>Bandas para Spark</p>
            </a>
            <a class="galeria-item" style="text-decoration: none; color: black;">
                <img src="./assets/img/BujesTIjeraHyundaiI10.webp" alt="Repuesto 5" width="200" height="200">
                <h3>130.000</h3>
                <p>2 Bujes de tijera de Hyundai i10</p>
            </a>
            <a class="galeria-item" style="text-decoration: none; color: black;">
                <img src="./assets/img/pastiLogan.jpeg" alt="Repuesto 6" width="200" height="200">
                <h3>90.500</h3>
                <p>Pastillas de Logan</p>
            </a>
            <a class="galeria-item" style="text-decoration: none; color: black;">
                <img src="./assets/img/RotulaKiaION.webp" alt="Repuesto 7" width="200" height="200">
                <h3>40.000</h3>
                <p>Rótula de Kia Ion</p>
            </a>
            <a class="galeria-item" style="text-decoration: none; color: black;">
                <img src="./assets/img/SoporteMotorKIaION.jpg" alt="Repuesto 8" width="200" height="200">
                <h3>148.000</h3>
                <p>Soporte de motor Kia Ion</p>
            </a>
            <a class="galeria-item" style="text-decoration: none; color: black;">
                <img src="./assets/img/SoporteMotorLogan8Valvulas.jpg" alt="Repuesto 9" width="200" height="200">
                <h3>185.000</h3>
                <p>Soporte Motor Logan/Sandero 2016</p>
            </a>
            <a class="galeria-item" style="text-decoration: none; color: black;">
                <img src="./assets/img/soporteMotorSparkGT.webp" alt="Repuesto 10" width="200" height="200">
                <h3>140.000</h3>
                <p>Soporte de Motor Spark GT / Beat</p>
            </a>
            <a class="galeria-item" style="text-decoration: none; color: black;">
                <img src="./assets/img/SoporteTraseroMotorKiaION.webp" alt="Repuesto 11" width="200" height="200">
                <h3>156.000</h3>
                <p>Soporte trasero de motor Kia Ion</p>
            </a>
            <a class="galeria-item" style="text-decoration: none; color: black;">
                <img src="./assets/img/SopoteMotorFrontalSparklife.webp" alt="Repuesto 12" width="200" height="200">
                <h3>136.000</h3>
                <p>Soporte frontal Spark LIFE</p>
            </a>
            <a class="galeria-item" style="text-decoration: none; color: black;">
                <img src="./assets/img/SoprteTraseroMotorLogan8Val.webp" alt="Repuesto 13" width="200" height="200">
                <h3>119.000</h3>
                <p>Soporte trasero de motor Logan/Sandero/Stepway</p>
            </a>
            <a class="galeria-item" style="text-decoration: none; color: black;">
                <img src="./assets/img/TijeraDerechaKiaION.webp" alt="Repuesto 14" width="200" height="200">
                <h3>201.000</h3>
                <p>Tijera derecha Kia Ion</p>
            </a>
            <a class="galeria-item" style="text-decoration: none; color: black;">
                <img src="./assets/img/tijeraIzquierdaKIaION.webp" alt="Repuesto 15" width="200" height="200">
                <h3>201.000</h3>
                <p>Tijera izquierda Kia Ion</p>
            </a>
            <a class="galeria-item" style="text-decoration: none; color: black;">
                <img src="./assets/img/AmortiguadoresSparkGT.webp" alt="Repuesto 16" width="200" height="200">
                <h3>530.000</h3>
                <p>Amortiguadores + soportes + guarda polvos para Spark GT</p>
            </a>
            <a class="galeria-item" style="text-decoration: none; color: black;">
                <img src="./assets/img/AmortiguadoresKia ION.webp" alt="Repuesto 17" width="200" height="200">
                <h3>427.000</h3>
                <p>Amortiguadores para Kia Picanto ION</p>
            </a>
            <a class="galeria-item" style="text-decoration: none; color: black;">
                <img src="./assets/img/DiscosFenoKiaION.webp" alt="Repuesto 18" width="200" height="200">
                <h3>315.000</h3>
                <p>Discos de frenos de Kia Picanto ION</p>
            </a>
            <a class="galeria-item" style="text-decoration: none; color: black;">
                <img src="./assets/img/DiscosFrenoSparkGT.webp" alt="Repuesto 19" width="200" height="200">
                <h3>359.000</h3>
                <p>Discos de freno para Spark GT</p>
            </a>
            <a class="galeria-item" style="text-decoration: none; color: black;">
                <img src="./assets/img/DiscosFRenoLogan.webp" alt="Repuesto 20" width="200" height="200">
                <h3>425.409</h3>
                <p>Discos de freno de Logan</p>
            </a>
            <a class="galeria-item" style="text-decoration: none; color: black;">
                <img src="./assets/img/LiquidoFrenos.webp" alt="Repuesto 21" width="200" height="200">
                <h3>52.000</h3>
                <p>Líquido de frenos</p>
            </a>
        </section>
    </main>


    <!-- Start Footer -->
    <footer class="bg-dark" id="tempaltemo_footer">
        <div class="container">
            <div class="row">

                <div class="col-md-4 pt-5">
                    <h2 class="h2 text-success border-bottom pb-3 border-light logo">Frenos y Suspensiones</h2>
                    <ul class="list-unstyled text-light footer-link-list">
                        <li>
                            <i class="fas fa-map-marker-alt fa-fw"></i>
                            Cra 87 # 51B–78S', Bosa, Bogotá
                        </li>
                        <li>
                            <i class="fa fa-phone fa-fw"></i>
                            <a class="text-decoration-none" href="tel:3104298615">3104298615</a>
                        </li>
                        <li>
                            <i class="fa fa-envelope fa-fw"></i>
                            <a class="text-decoration-none" href="mailto:frenosysupenciones0@gmail.com">frenosysupenciones0@gmail.com</a>
                        </li>
                    </ul>
                </div>

                <div class="col-md-4 pt-5">
                    <h2 class="h2 text-light border-bottom pb-3 border-light">Productos</h2>
                    <ul class="list-unstyled text-light footer-link-list">
                        <li><a class="text-decoration-none" href="#">Amortiguador de Logan</a></li>
                        <li><a class="text-decoration-none" href="#">Bandas de Logan</a></li>
                        <li><a class="text-decoration-none" href="#">Bandas para Spark</a></li>
                        <li><a class="text-decoration-none" href="#">Amortiguador de Spark</a></li>
                        <li><a class="text-decoration-none" href="#">Soporte de motor Kia Ion</a></li>
                        <li><a class="text-decoration-none" href="#">Soporte Motor Logan/Sandero 2016</a></li>
                        <li><a class="text-decoration-none" href="#">Soporte de Motor Spark GT / Beat</a></li>
                    </ul>
                </div>

                <div class="col-md-4 pt-5">
                    <h2 class="h2 text-light border-bottom pb-3 border-light">Informacion</h2>
                    <ul class="list-unstyled text-light footer-link-list">
                        <li><a class="text-decoration-none" href="">Inicio</a></li>
                        <li><a class="text-decoration-none" href="#">Acerca de</a></li>
                        <li><a class="text-decoration-none" href="productos.php">Productos</a></li>
                        <li><a class="text-decoration-none" href="#">Contactenos</a></li>
                        <li><a class="text-decoration-none" href="iniciarsesion.php">Agendar Cita</a></li>

                    </ul>
                </div>

            </div>

            <div class="row text-light mb-4">
                <div class="col-12 mb-3">
                    <div class="w-100 my-3 border-top border-light"></div>
                </div>
                <div class="col-auto me-auto">
                    <ul class="list-inline text-left footer-icons">
                        <li class="list-inline-item border border-light rounded-circle text-center">
                            <a class="text-light text-decoration-none" target="_blank" href="http://facebook.com/"><i class="fab fa-facebook-f fa-lg fa-fw"></i></a>
                        </li>
                        <li class="list-inline-item border border-light rounded-circle text-center">
                            <a class="text-light text-decoration-none" target="_blank" href="https://www.instagram.com/"><i class="fab fa-instagram fa-lg fa-fw"></i></a>
                        </li>
                        <li class="list-inline-item border border-light rounded-circle text-center">
                            <a class="text-light text-decoration-none" target="_blank" href="https://twitter.com/"><i class="fab fa-twitter fa-lg fa-fw"></i></a>
                        </li>
                        <li class="list-inline-item border border-light rounded-circle text-center">
                            <a class="text-light text-decoration-none" target="_blank" href="https://www.linkedin.com/"><i class="fab fa-linkedin fa-lg fa-fw"></i></a>
                        </li>
                    </ul>
                </div>
                <div class="col-auto">
                    <label class="sr-only" for="subscribeEmail">Correo Electronico</label>
                    <div class="input-group mb-2">
                        <input type="text" class="form-control bg-dark border-light" id="subscribeEmail" placeholder="Correo Electronico">
                        <div class="input-group-text btn-success text-light">Suscribete</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="w-100 bg-black py-3">
            <div class="container">
                <div class="row pt-2">
                    <div class="col-12">
                        <p class="text-left text-light">
                            Copyright &copy; Frenos y Suspensiones
                        </p>
                    </div>
                </div>
            </div>
        </div>

    </footer>
    <!-- End Footer -->
    <script>
   document.getElementById("user-icon").addEventListener("click", function() {
    var userIcon = document.getElementById("user-icon");
    var userListContainer = document.getElementById("user-list-container");

    // Obtiene la posición del icono de usuario
    var rect = userIcon.getBoundingClientRect();

    // Establece la posición del contenedor de la lista justo debajo del icono
    userListContainer.style.left = rect.left + "px";
    userListContainer.style.top = rect.bottom + "px";

    userListContainer.classList.toggle("show");
});

// Oculta la lista si se hace clic en cualquier lugar fuera de la lista
document.addEventListener("click", function(event) {
    var userListContainer = document.getElementById("user-list-container");
    if (event.target.closest("#user-icon") === null && !userListContainer.contains(event.target)) {
        userListContainer.classList.remove("show");
    }
});

</script>
    <!-- Start Script -->
    <script src="assets/js/jquery-1.11.0.min.js"></script>
    <script src="assets/js/jquery-migrate-1.2.1.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/templatemo.js"></script>
    <script src="assets/js/custom.js"></script>
    <!-- End Script -->
</body>

</html>

