<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/templatemo.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;200;300;400;500;700;900&display=swap">
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
    <link rel="stylesheet" href="assets/css/pago.css">
    <title>Carrito de Compras</title>
</head>
<style>
    body {
        background-color: white;
    }
</style>

<body>
    <!-- Header -->
    <nav class="navbar navbar-expand-lg navbar-light shadow custom-header">
        <div class="container d-flex justify-content-between align-items-center">
            <a class="navbar-brand text-success logo h1 align-self-center" href="cliente.php">
                Frenos y Suspensiones
            </a>
            <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#templatemo_main_nav" aria-controls="templatemo_main_nav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse flex-fill d-lg-flex justify-content-lg-between" id="templatemo_main_nav">
                <div class="flex-fill">
                    <ul class="nav navbar-nav d-flex flex-row mx-lg-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="cliente.php">Inicio</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="sobre.php">Acerca De</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="inventa.php">Productos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="l.php">Contactenos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="agendaclien.php">Agendar Cita</a>
                        </li>
                    </ul>
                </div>
                <a class="nav-icon position-relative text-decoration-none" href="#">
                    <i class="fa fa-fw fa-user text-dark mr-3"></i>
                </a>
            </div>
        </div>
    </nav>

    <main>
        <section id="servicios">
            <center>
                <h2>Servicios en el Carrito</h2>
            </center>
            <ul class="servicios-lista">
                <li class="servicio-item">
                    <div class="servicio-titulo" id="carrito-servicio">Servicio Seleccionado</div>
                    <div class="servicio-precio" id="carrito-precio">$120.000</div>
                </li>
            </ul>
            <!-- Campo oculto para almacenar el precio del servicio seleccionado -->
            <input type="hidden" id="precio-servicio" value="$120.000">
        </section>

        <section id="pagos">
            <h2>Métodos de Pago</h2>
            <!-- Formulario de Pago y Campos según el método de pago -->
            <form id="formulario-pago">
                <br>
                <label for="nombre">Nombres Y Apellidos:</label>
                <br>
                <input type="text" id="nombre" required><br>

                <label for="metodo-pago">Seleccione un método de pago:</label>
                <br>
                <select id="metodo-pago" required>
                    <option value="efectivo">Efectivo</option>
                    <option value="tarjeta">Tarjeta de Crédito/Débito</option>
                    <option value="nequi">Nequi</option>
                </select><br><br>

                <!-- Campos para Efectivo -->
                <div id="efectivo-fields" style="display: none;">
                    <label for="efectivo-entrega">Monto a Entregar en Efectivo:</label>
                    <input type="text" id="efectivo-entrega">
                </div>

                <!-- Campos para Tarjeta de Crédito/Débito -->
                <div id="tarjeta-fields" style="display: none;">
                    <label for="tarjeta">Número de Tarjeta:</label>
                    <input type="text" id="tarjeta" required><br><br>

                    <label for="vencimiento">Fecha de Vencimiento:</label>
                    <input type="text" id="vencimiento" placeholder="MM/YY" required><br><br>

                    <label for="cvv">CVV:</label>
                    <input type="text" id="cvv" required><br><br>
                </div>

                <!-- Campos para Nequi -->
                <div id="nequi-fields" style="display: none;">
                    <label for="nequi-telefono">Número de Teléfono Nequi:</label>
                    <input type="text" id="nequi-telefono">
                </div>

                <button type="submit">Realizar Pago</button>
            </form>
        </section>
    </main>

   
    <!-- Footer -->
    <footer class="bg-dark" id="tempaltemo_footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4 pt-5">
                    <h2 class="h2 text-success border-bottom pb-3 border-light logo">Frenos y Suspensiones</h2>
                    <ul class="list-unstyled text-light footer-link-list">
                        <li>
                            <i class="fas fa-map-marker-alt fa-fw"></i>
                            Cra 87 # 51B–78S', Bosa, Bogotá
                        </li>
                        <li>
                            <i class="fa fa-phone fa-fw"></i>
                            <a class="text-decoration-none" href="tel:3104298615">3104298615</a>
                        </li>
                        <li>
                            <i class="fa fa-envelope fa-fw"></i>
                            <a class="text-decoration-none" href="mailto:frenosysupenciones0@gmail.com">frenosysupenciones0@gmail.com</a>
                        </li>
                    </ul>
                </div>

                <div class="col-md-4 pt-5">
                    <h2 class="h2 text-light border-bottom pb-3 border-light">Productos</h2>
                    <ul class="list-unstyled text-light footer-link-list">
                        <li><a class="text-decoration-none" href="#">Amortiguador de Logan</a></li>
                        <li><a class="text-decoration-none" href="#">Bandas de Logan</a></li>
                        <li><a class="text-decoration-none" href="#">Bandas para Spark</a></li>
                        <li><a class="text-decoration-none" href="#">Amortiguador de Spark</a></li>
                        <li><a class="text-decoration-none" href="#">Soporte de motor Kia Ion</a></li>
                        <li><a class="text-decoration-none" href="#">Soporte Motor Logan/Sandero 2016</a></li>
                        <li><a class="text-decoration-none" href="#">Soporte de Motor Spark GT / Beat</a></li>
                    </ul>
                </div>

                <div class="col-md-4 pt-5">
                    <h2 class="h2 text-light border-bottom pb-3 border-light">Informacion</h2>
                    <ul class="list-unstyled text-light footer-link-list">
                        <li><a class="text-decoration-none" href="index.php">Inicio</a></li>
                        <li><a class="text-decoration-none" href="about.php">Acerca de</a></li>
                        <li><a class="text-decoration-none" href="shop.php">Productos</a></li>
                        <li><a class="text-decoration-none" href="contact.php">Contactenos</a></li>
                        <li><a class="text-decoration-none" href="iniciarsesion.php">Agendar Cita</a></li>
                    </ul>
                </div>
            </div>

            <div class="row text-light mb-4">
                <div class="col-12 mb-3">
                    <div class="w-100 my-3 border-top border-light"></div>
                </div>
                <div class="col-auto me-auto">
                    <ul class="list-inline text-left footer-icons">
                        <li class="list-inline-item border border-light rounded-circle text-center">
                            <a class="text-light text-decoration-none" target="_blank" href="http://facebook.com/"><i class="fab fa-facebook-f fa-lg fa-fw"></i></a>
                        </li>
                        <li class="list-inline-item border border-light rounded-circle text-center">
                            <a class="text-light text-decoration-none" target="_blank" href="https://www.instagram.com/"><i class="fab fa-instagram fa-lg fa-fw"></i></a>
                        </li>
                        <li class="list-inline-item border border-light rounded-circle text-center">
                            <a class="text-light text-decoration-none" target="_blank" href="https://twitter.com/"><i class="fab fa-twitter fa-lg fa-fw"></i></a>
                        </li>
                        <li class="list-inline-item border border-light rounded-circle text-center">
                            <a class="text-light text-decoration-none" target="_blank" href="https://www.linkedin.com/"><i class="fab fa-linkedin fa-lg fa-fw"></i></a>
                        </li>
                    </ul>
                </div>
                <div class="col-auto">
                    <label class="sr-only" for="subscribeEmail">Correo Electronico</label>
                    <div class="input-group mb-2">
                        <input type="text" class="form-control bg-dark border-light" id="subscribeEmail" placeholder="Correo Electronico">
                        <div class="input-group-text btn-success text-light">Suscribete</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="w-100 bg-black py-3">
            <div class="container">
                <div class="row pt-2">
                    <div class="col-12">
                        <p class="text-left text-light">
                            Copyright &copy; Frenos y Suspensiones
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Close Footer -->

    <script>
        // JavaScript para obtener el servicio seleccionado de la URL
        const params = new URLSearchParams(window.location.search);
        const servicioSeleccionado = params.get("servicio");
        const servicioSelect = document.getElementById("carrito-servicio");
        servicioSelect.textContent = servicioSeleccionado || "Servicio Seleccionado";

        // Obtener el campo oculto y el precio del servicio
        const precioServicioInput = document.getElementById("precio-servicio");
        const precioServicio = parseFloat(precioServicioInput.value);

        // JavaScript para mostrar u ocultar los campos según el método de pago seleccionado
        const metodoPagoSelect = document.getElementById("metodo-pago");
        const efectivoFields = document.getElementById("efectivo-fields");
        const tarjetaFields = document.getElementById("tarjeta-fields");
        const nequiFields = document.getElementById("nequi-fields");

        // Función para actualizar el precio del servicio en el formulario
        function actualizarPrecioServicio() {
            const servicioPrecioElement = document.getElementById("carrito-precio");
            servicioPrecioElement.textContent = `$${precioServicio.toFixed(2)}`;
        }

        metodoPagoSelect.addEventListener("change", () => {
            const selectedOption = metodoPagoSelect.value;
            switch (selectedOption) {
                case "efectivo":
                    efectivoFields.style.display = "block";
                    tarjetaFields.style.display = "none";
                    nequiFields.style.display = "none";
                    break;
                case "tarjeta":
                    efectivoFields.style.display = "none";
                    tarjetaFields.style.display = "block";
                    nequiFields.style.display = "none";
                    break;
                case "nequi":
                    efectivoFields.style.display = "none";
                    tarjetaFields.style.display = "none";
                    nequiFields.style.display = "block";
                    break;
                default:
                    efectivoFields.style.display = "none";
                    tarjetaFields.style.display = "none";
                    nequiFields.style.display = "none";
            }
        });

        // JavaScript para redireccionar después de realizar el pago
        document.getElementById("formulario-pago").addEventListener("submit", function(event) {
            event.preventDefault(); // Prevenir el envío del formulario por defecto

            // Agregar aquí la lógica de procesamiento del pago, si es necesario

            // Redireccionar a la página de confirmación de pago
            window.location.href = "error500.php";
        });

        // Actualizar el precio del servicio cuando se carga la página
        actualizarPrecioServicio();
    </script>
</body>
</html>
