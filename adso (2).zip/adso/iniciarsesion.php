<!DOCTYPE html>
<html lang="en">

<head>
  
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
  <link rel="stylesheet" href="assets/css/iniciar.css">
  <title>Página Iniciar Sesión</title>
</head>

<body>
  <div class="container" id="container">
    <div class="form-container sign-up">
    <form method="post" action="registro.php" onsubmit="return validateRegistration()">
        <h1>Crear Cuenta</h1>
        <div class="social-icons">
          <a href="#" class="icon"><i class="fa-brands fa-google-plus-g"></i></a>
          <a href="#" class="icon"><i class="fa-brands fa-facebook-f"></i></a>
          <a href="#" class="icon"><i class="fa-brands fa-github"></i></a>
          <a href="#" class="icon"><i class="fa-brands fa-linkedin-in"></i></a>
        </div>
        <input type="text" placeholder="Nombre Completo" name="fullName" id="fullName">
        <input type="email" placeholder="Email" name="email" id="email">
        <input type="tel" placeholder="Telefono" name="telefono" id="telefono">
        <input type="password" placeholder="Contraseña" name="password" id="password">
        <div class="consent-container">
          <input type="checkbox" id="consentCheckbox" name="consentCheckbox">
          <label for="consentCheckbox">Acepto el tratamiento de datos</label>
        </div>
        <button type="submit">Registrar</button>
      </form>
    </div>
    <div class="form-container sign-in">
      <form method="post" action="cliente.php">
        <h1>Iniciar Sesión</h1>
        <div class="social-icons">
          <a href="#" class="icon"><i class="fa-brands fa-google-plus-g"></i></a>
          <a href="#" class="icon"><i class="fa-brands fa-facebook-f"></i></a>
          <a href="#" class="icon"><i class="fa-brands fa-github"></i></a>
          <a href="#" class="icon"><i class="fa-brands fa-linkedin-in"></i></a>
        </div>
        <span>Use su correo</span>
        <input type="email" placeholder="Email" name="loginEmail">
        <input type="password" placeholder="Contraseña" name="loginPassword">
        <a href="olvide.php">¿Olvidaste tu contraseña?</a>
        <button type="submit">Ingresar</button>
      </form>
    </div>
    <div class="toggle-container">
      <div class="toggle">
        <div class="toggle-panel toggle-left">
          <h1>Bienvenidos</h1>
          <p>Regístrese con sus datos personales</p>
          <button class="hidden" id="login">Iniciar Sesión</button>
        </div>
        <div class="toggle-panel toggle-right">
          <h1>Bienvenidos!!</h1>
          <p>Ingrese sus datos personales</p>
          <button class="hidden" id="register">Registrarse</button>
        </div>
      </div>
    </div>

    <script src="assets/js/valid.js"></script>
    <script>
      function validateRegistration() {
        const fullName = document.getElementById('fullName').value;
        const email = document.getElementById('email').value;
        const telefono = document.getElementById('telefono').value;
        const password = document.getElementById('password').value;

        // Validaciones
        if (!fullName || !email || !telefono || !password) {
          alert('Por favor, complete todos los campos.');
          return false;
        }

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email) || !email.endsWith('@gmail.com')) {
          alert('Por favor, ingrese un correo electrónico válido de Gmail.');
          return false;
        }

        if (fullName.length < 3) {
          alert('El nombre debe contener al menos 3 letras.');
          return false;
        }

        if (!(/^\d+$/.test(telefono)) || telefono.length !== 10) {
          alert('El número de teléfono debe tener exactamente 10 números.');
          return false;
        }

        const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+])[A-Za-z\d!@#$%^&*()_+]{8,}$/;
        if (!passwordRegex.test(password)) {
          alert('La contraseña debe contener al menos 8 caracteres, incluyendo mayúsculas, minúsculas, números y caracteres especiales.');
          return false;
        }

        const consentCheckbox = document.querySelector('input[name="consentCheckbox"]');
        if (!consentCheckbox.checked) {
          alert('Por favor, acepte el tratamiento de datos para continuar.');
          return false;
        }

        // Redirige a la página de inicio de sesión después de la validación exitosa
        window.location.href = 'cliente.php';
        return true;
      }
    </script>

  </div>

  <?php
// registro.php

include 'conexion.php';

// Resto del código para manejar los datos del formulario y realizar operaciones en la base de datos
// ...
?>


</body>
</form>
</html>
